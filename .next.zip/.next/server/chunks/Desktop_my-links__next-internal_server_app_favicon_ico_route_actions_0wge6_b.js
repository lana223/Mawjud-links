module.exports=[92358,(e,o,d)=>{}];

//# sourceMappingURL=Desktop_my-links__next-internal_server_app_favicon_ico_route_actions_0wge6_b.js.map