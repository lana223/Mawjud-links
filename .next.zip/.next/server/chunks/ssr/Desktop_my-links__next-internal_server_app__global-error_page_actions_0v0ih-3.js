module.exports=[18533,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_my-links__next-internal_server_app__global-error_page_actions_0v0ih-3.js.map