module.exports=[58023,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_my-links__next-internal_server_app__not-found_page_actions_0v5t1zc.js.map