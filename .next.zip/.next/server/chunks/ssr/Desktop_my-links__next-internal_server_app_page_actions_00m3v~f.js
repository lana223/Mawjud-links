module.exports=[23450,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_my-links__next-internal_server_app_page_actions_00m3v~f.js.map