1:"$Sreact.fragment"
2:I[57283,["/_next/static/chunks/0z4.4_4i1ymb..js"],"default"]
3:I[29387,["/_next/static/chunks/0z4.4_4i1ymb..js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"OHkBegS1iWBcAFSTr82MB"}
