var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__0cq6jvz._.js")
R.c("server/chunks/Desktop_my-links__next-internal_server_app_favicon_ico_route_actions_0wge6_b.js")
R.m(8515)
module.exports=R.m(8515).exports
