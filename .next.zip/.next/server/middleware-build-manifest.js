globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/OHkBegS1iWBcAFSTr82MB/_buildManifest.js",
    "static/OHkBegS1iWBcAFSTr82MB/_ssgManifest.js",
    "static/OHkBegS1iWBcAFSTr82MB/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0~67xqgt0zaba.js",
    "static/chunks/0w2iejd7ec96g.js",
    "static/chunks/0y-s4w44~~w11.js",
    "static/chunks/turbopack-0sb~cdoha29kw.js"
  ]
};
